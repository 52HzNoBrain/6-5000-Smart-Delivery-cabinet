package data;

import java.util.ArrayList;
import java.util.Objects;
/*
* 此类用于验证取件码是否存在，并将会结果赋值给属性变量bo、
* */
public class SearchInfor {
    //获取存储数据的动态数组；
    ArrayList array = new ArrayData<>().getArray();
    LinkNode te;
    InforData infor;
    String pick_num;
    //判断取件码是否存在
    boolean bo;
    public boolean isBo() {
        return bo;
    }
    public SearchInfor(String pick_num){
        this.pick_num=pick_num;
        this.Serch();
    }
    /*查找*/
    public void Serch(){
        //遍历每个数据域
        for (int i = 0; i <array.size(); i++) {
            /*从array动态数组中获取第i个对象（i同是代表柜子的行数）-----array.get(i)返回的值是LinkData对象
            *    ((LinkData) array.get(i)).head-----返回的是第i行LinkData对象的头结点
            * */
            te = ((LinkData) array.get(i)).head;
            for (int j = 0; j < LinkData.colsize; j++) {
                //返回第i行，j列的InforData对象(将每个数据赋值给infor变量)
                infor= (InforData) te.next.data;
                //对infor值进行判空，不进行判空直接输出（属性）程序会报错
                if(Objects.equals(infor,null)){
                    //如果该数据域为空则，
                    te = te.next;
                }else {
                    //判断取件人输入的取件码是否存在
                    if(this.pick_num.equals(infor.getRandom_num())){
                        //条件成立，将快递取出，并更新该柜子的状态
                        te.next.data=null;
                        //目的：让GUI_Set界面进行弹窗显示。
                        this.bo=true;
                        //更新动态数组的值，（更新柜子状态）
                        new ArrayData<>().setArray(this.array);
                        //取出快递后直接跳出该方法。
                        return;
                    }
                    //条件不成立，将指针指向下一个数据域
                    te = te.next;
                }
            }
        }
        //循环结束代表没有找到相符合的取件码。
        this.bo=false;
    }
}
