package data;

import java.util.Random;

/*
* 此类用于生成随机取件码，将订单号-手机号-取件码绑定在一起
* */
public class InforData {
    String order_num;
    String phone_num;

    public String getRandom_num() {
        return random_num;
    }

    String random_num;
    //创建一个快递信息对象时必须传订单号和手机号。
    public InforData(String order_num,String phone_num){
        this.CreRandom_num();
        this.setOrder_num(order_num);
        this.setPhone_num(phone_num);
        System.out.println("取件码："+this.random_num);
        System.out.println("---------------------------");
    }
    //生成8为随机数的方法。
    private void CreRandom_num(){
        String str = null;
        for(int i=0;i<8;i++){
            str+=new Random().nextInt(10);
        }
        this.random_num=str.substring(4,12);
    }
    public String getOrder_num() {
        return order_num;
    }

    public void setOrder_num(String order_num) {
        this.order_num = order_num;
    }

    public String getPhone_num() {
        return phone_num;
    }

    public void setPhone_num(String phone_num) {
        this.phone_num = phone_num;
    }

    public static void main(String[] args) {

    }
}
