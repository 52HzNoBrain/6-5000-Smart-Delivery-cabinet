package data;

/*
 * 一个LinkData类对象代表快递柜的一行，一行有6个快递柜
 * */
public class LinkData<E> {
    public static int colsize = 6;                     //快递柜的列数
    public LinkNode<E> head;
    public LinkNode<E> temp;

    public LinkData() {
        head = new LinkNode<E>();
        temp = head;
        for (int i = 0; i < colsize; i++) {
            temp.next = new LinkNode<>();
            temp = temp.next;
        }

    }
}
