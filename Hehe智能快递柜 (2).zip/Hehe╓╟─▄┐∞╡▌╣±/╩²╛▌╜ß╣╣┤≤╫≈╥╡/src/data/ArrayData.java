package data;

import java.util.ArrayList;
import java.util.Objects;

/*
  * 链表数组类，用于存放每个行对象（LinkData对象），数组的长度为8.构成一个8行6列的快递存储模式。
  * */
 public class ArrayData<E> {
     public static int rowsize = 8;
     public static ArrayList<LinkData> array;
     //先对动态数组的状态进判断，防止没创建一个动态数组类对象时，重新初始化数据。
    public ArrayData(){
        if(Objects.equals(array,null)){
            array=new ArrayList<>();
            this.initArray();
        }
    }
    public void initArray(){
        LinkNode temp;                                  //实现属性type更改的一个结点变量
        /*
         * 对每行每列中的结点对象的属性进行赋值。
         * */
        for (int i = 0; i < this.rowsize; i++) {
            array.add(new LinkData());                                      //新建一个空的LinkData对象，并添加到链表数组array中。
            temp=array.get(i).head;
            /* 对一行中每列中的结点对象的属性值进行赋值
             * */
            for (int j = 0; j < LinkData.colsize; j++) {
                /*
                 * 将前两行的结点对象的属性值赋值为big
                 * */

                if (i < 2) {
                    temp.next.type=LinkNode.Type.big;
                    //temp.next.data=1;
                    temp=temp.next;
                }
                /*将前3-4的结点对象的属性值赋值为mid
                 * */
                else if (i < 4) {
                    temp.next.type=LinkNode.Type.mid;
                    temp=temp.next;
                }
                /*将其他行的结点对象的属性值赋值为sma
                 * */else {
                    temp.next.type=LinkNode.Type.sma;
                    temp=temp.next;
                }
            }
        }
    }
    public ArrayList getArray(){
        return this.array;
    }
    public void setArray(ArrayList e){this.array=e;}

 }
