package data;

/*
 * 结点类，一个结点包含一个数据域喝指针域
 * */
public class LinkNode<E> {
    /*
     * 枚举类型用来区分快递柜的大小规格
     * */
    enum Type {
        big, mid, sma;
    }

    public E data;                                      //数据域
    public LinkNode<E> next;                          //后驱指针
    public Type type;

    public LinkNode() {
        next = null;
        data = null;
        type = null;
    }
}
