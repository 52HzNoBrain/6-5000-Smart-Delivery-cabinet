package AC_FC;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

/*实现FocusListener接口的方法, 重载focusGained()方法,当获得焦点时,
    判断文本框的内容是否仍然是提示信息, 而不是用户输入信息, 如是, 则清除,
    重载focusLost()方法, 当失去焦点时, 判断文本框是否为空, 是就恢复提示*/
public  class TextFc implements FocusListener {
    String str;
    JTextField text;
    public TextFc (String str,JTextField text){
        this.str=str;
        this.text=text;
    }
    @Override
    public void focusGained(FocusEvent e) {
        if(this.text.getText().equals(this.str)){
            this.text.setForeground(Color.BLACK);
            this.text.setText("");
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        if(this.text.getText().equals("")){
            this.text.setText(this.str);
            this.text.setForeground(Color.LIGHT_GRAY);
        }
    }
}
