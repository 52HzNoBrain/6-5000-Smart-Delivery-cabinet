package app;

import javax.swing.*;
import java.awt.*;

public class MyJFrame extends JFrame {
    JPanel GUIJPanel=new JPanel();                                                        //图形界面容器
    public MyJFrame(){
        super();
        this.setTitle("Hehe智能快递柜");
        //设置点窗口X时的效果，3==system.exit(0)
        this.setDefaultCloseOperation(3);
        //设置窗口的大小。
        this.setSize(1000, 800);
        //视窗显示在屏幕中间
        this.setLocationRelativeTo(null);
        //设置背景颜色
        this.getContentPane().setBackground(new Color(251,255,242));
        //取消默认流式布局，采用精准布局
        this.GUIJPanel.setLayout(null);
        //将容器对象设置给此GUI窗口
        this.setContentPane(this.GUIJPanel);
        //设置窗口不可拉伸s
        this.setResizable(false);
        //设置窗口可见。
        this.setVisible(true);
    }
}
