package app;

import AC_FC.TextFc;
import Module_Beautify.MyJButton;
import Module_Beautify.MyJTextFileldlimit;
import Module_Beautify.MyTextBorder;
import data.ArrayData;
import data.InforData;
import data.LinkData;
import data.LinkNode;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Objects;
/*
* 派件界面
* */
public class Admin_Send extends MyJFrame{
    //记录点击柜子的位置
    public static int i,j;
    JLabel title=new JLabel("派件界面");
    JTextField phone_text =new JTextField("请输入11位手机号码",50);
    JTextField order_text=new JTextField("请输入快递单号",50);
    JLabel order_jlabel=new JLabel("订单号：");
    JLabel phone_jlabel=new JLabel("手机号：");
    JButton[] num=new GUI_Set("ww").getNumButton();                                     //形参没有实际意义，防止再创一次GUI_Set窗口，获取GUI_set的数字键盘
    JButton send_Button =new MyJButton("派件");                                         //取件按钮
    JButton Empty_text=new MyJButton("清空");                                           //清空按钮
    JButton Back_Button =new MyJButton("返回");
    public Admin_Send(int i,int j){
        this.i=i;
        this.j=j;
        this.AddModule();
        this.SetModule();
        this.SetAddNum();
        //文本框鼠标响应和其他按钮监听器。
        this.AddAc_Fc();
    }

    //添加组件的方法
    public void AddModule(){
        this.GUIJPanel.add(title);
        this.GUIJPanel.add(order_text);
        this.GUIJPanel.add(phone_text);
        this.GUIJPanel.add(send_Button);
        this.GUIJPanel.add(Empty_text);
        this.GUIJPanel.add(Back_Button);
        this.GUIJPanel.add(order_jlabel);
        this.GUIJPanel.add(phone_jlabel);
    }

    //设置组件的位置及大小
    public void SetModule(){
        //标题
        this.title.setBounds(400,10,600,50);
        this.title.setFont(new Font("TimesRoman",Font.PLAIN,40));
        this.order_jlabel.setBounds(90,80,100,60);
        this.phone_jlabel.setBounds(90,160,100,60);
        this.order_jlabel.setFont(new Font("TimesRoman",Font.PLAIN,25));
        this.phone_jlabel.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //文本框
        this.order_text.setBounds(200,80,600,60);
        this.phone_text.setBounds(200,160,600,60);
        //限制文本框长度和设置文本框样式
        this.phone_text.setDocument(new MyJTextFileldlimit(11,this.phone_text,"请输入11位手机号码",20));
        this.order_text.setDocument(new MyJTextFileldlimit(19,this.order_text,"请输入快递单号",20));
        //清空按钮
        this.Empty_text.setBounds(420,610,160,90);
        this.Empty_text.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //设置取件按钮
        this.send_Button.setBounds(660,610,160,90);
        this.send_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //返回按钮
        this.Back_Button.setBounds(20,20,100,50);
        this.Back_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
    }

    private void SetAddNum(){
        //添加数字键盘和添加监听事件
        int i=0;
        int num=180;
        for (JButton jButton : this.num) {
            this.GUIJPanel.add(jButton);
            if(i<3){
                jButton.setBounds(num,235,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                if(i==2)
                    num=180;
                i++;
            }
            else if(i<6)
            {
                jButton.setBounds(num,360,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                if(i==5)
                    num=180;
                i++;

            }
            else if(i<9)
            {
                jButton.setBounds(num,485,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                if(i==8)
                    num=180;
                i++;
            }
            else{
                jButton.setBounds(num,610,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
            }
            //设置按钮监听器
            jButton.addActionListener(new MyAc());
        }
    }
    public void AddAc_Fc(){
        //文本消失和恢复
        this.phone_text.addFocusListener(new TextFc("请输入11位手机号码",this.phone_text));
        this.order_text.addFocusListener(new TextFc("请输入快递单号",this.order_text));
        //鼠标点击事件
        //文本框分开输入
        this.phone_text.addMouseListener(new MyMouse("手机号"));
        this.order_text.addMouseListener(new MyMouse("订单号"));
        //监听器
        this.Empty_text.addActionListener(new MyAc());
        this.send_Button.addActionListener(new MyAc());
        this.Back_Button.addActionListener(new MyAc());
    }

    //监听器
    class MyAc implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String BuStr=e.getActionCommand();
             if(BuStr.equals("清空")){
                 if(new textmouse().getMouse()==true){
                     Admin_Send.this.order_text.setText("请输入快递单号");
                     Admin_Send.this.order_text.setForeground(Color.LIGHT_GRAY);
                 }
                 else if(new textmouse().getMouse()==false){
                     Admin_Send.this.phone_text.setText("请输入11位手机号码");
                     Admin_Send.this.phone_text.setForeground(Color.LIGHT_GRAY);
                 }
            }else if(BuStr.equals("派件")){
                 if(Admin_Send.this.order_text.getText().length()==0||Admin_Send.this.order_text.getText().equals("请输入快递单号"))
                     JOptionPane.showMessageDialog(Admin_Send.this.GUIJPanel, "派件失败！\n订单号为空");
                 else if(Admin_Send.this.phone_text.getText().length()==11){
                     ArrayData use=new ArrayData<>();
                     ArrayList array=use.getArray();
                     LinkData li;
                     LinkNode temp ;
                     li = (LinkData) array.get(i);
                     temp = li.head.next;
                     for (int k = 0; k < j + 1; k++) {
                         if (k == j) {
                             if (Objects.equals(temp.data, null)) {                             //派件时先对柜子的状态进行检查，柜子闲置才允许派件。
                                 //将快递信息的对象存到数据域当中
                                 temp.data= new InforData(Admin_Send.this.order_text.getText(),Admin_Send.this.phone_text.getText());
                                 //更新数据
                                 use.setArray(array);
                                 JOptionPane.showMessageDialog(Admin_Send.this.GUIJPanel, "派件成功！");
                                 new Admin_Set<>();
                                 Admin_Send.this.dispose();
                             } else{
                                 //柜子占用无法派件
                                 JOptionPane.showMessageDialog(Admin_Send.this.GUIJPanel, "派件失败！\n该柜子被占用");
                                 new Admin_Set<>();
                                 Admin_Send.this.dispose();
                             }
                         }
                         //指针指向下一个结点
                         temp = temp.next;
                     }

                 }else
                     JOptionPane.showMessageDialog(Admin_Send.this.GUIJPanel, "派件失败！\n请输入正确的11位手机号");
            }else if(BuStr.equals("返回")){
                 new Admin_Set<>();
                 Admin_Send.this.dispose();
            }else{
                 //判断数字按钮响应的对话框
                 if(new textmouse().getMouse()==true){
                     if(Admin_Send.this.order_text.getText().equals("请输入快递单号"))
                         Admin_Send.this.order_text.setText("");
                     Admin_Send.this.order_text.setForeground(Color.BLACK);
                     //设置当按钮输入为19位时，不再响应其按钮点击事件
                     if(Admin_Send.this.order_text.getText().length()<19){
                         Admin_Send.this.order_text.setText(Admin_Send.this.order_text.getText()+BuStr);
                     }
                     else return;
                 }
                 else if(new textmouse().getMouse()==false){
                     if(Admin_Send.this.phone_text.getText().equals("请输入11位手机号码"))
                         Admin_Send.this.phone_text.setText("");
                     Admin_Send.this.phone_text.setForeground(Color.BLACK);
                     //设置当按钮输入为11位时，不再响应其按钮点击事件
                     if(Admin_Send.this.phone_text.getText().length()<11){
                         Admin_Send.this.phone_text.setText(Admin_Send.this.phone_text.getText()+BuStr);
                     }
                     else return;
                 }
                 else return;
            }
        }
    }

    //鼠标点击事件
    class MyMouse implements MouseListener{
        String string;
        public MyMouse(String string){
            this.string=string;
        }
        @Override
        public void mouseClicked(MouseEvent e) {
            if(this.string.equals("手机号")){
                new textmouse().setMouse(false);
            }else if(this.string.equals("订单号")){
                new textmouse().setMouse(true);
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    }
    //获取鼠标光标位置所在文本框
    //ture：鼠标停留在快递单号文本框
    //false：鼠标停留在手机号文本框
    class textmouse{
        public static boolean mouse;
        public textmouse(){

        }
        public boolean getMouse(){
            return this.mouse;
        }
        public void setMouse(boolean mouse){
            this.mouse=mouse;
        }
    }
}

