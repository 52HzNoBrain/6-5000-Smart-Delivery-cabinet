package app;

import Module_Beautify.MyJButton;
import data.ArrayData;
import data.InforData;
import data.LinkData;
import data.LinkNode;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Objects;

/*柜子选择界面
* */
public class Admin_Set<E> extends MyJFrame {
    //快递柜按钮的二位数组
    MyJButton[][] bt;
    MyJButton Exit_Button=new MyJButton("退出");
    public static final int rowsize = 8;                                      //快递柜的行数
    public static final int colsize = 6;                                      //快递柜的列数

    public Admin_Set() {
        this.SetAddbt();
        this.GUIJPanel.add(Exit_Button);
        this.Exit_Button.setBounds(10,680,100,50);
        this.Exit_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
        this.Exit_Button.BUTTON_COLOR1 = new Color(177, 50, 135, 87);
        this.Exit_Button.BUTTON_COLOR2 = new Color(201, 0, 47);
        this.Exit_Button.addActionListener(new MyAc());
    }

    /*初始化快递柜子按钮
     * */
    private void getButton() {
        MyJButton[][] num = new MyJButton[rowsize][colsize];
        for (int i = 0; i < rowsize; i++) {
            for (int j = 0; j < colsize; j++) {
                num[i][j] = new MyJButton("");
            }
        }
        this.bt = num;
    }

    private void SetAddbt() {
        //初始化快递柜子按钮
        this.getButton();
        //设置柜子按钮的显示位置等。
        int x = 10, y = 0, width = 140, height;
        for (int i = 0; i < rowsize; i++) {
            if (i < 2) {
                height = 80;
            } else if (i < 4) {
                height = 65;
            } else {
                height = 50;
            }
            for (int j = 0; j < colsize; j++) {
                //将每个柜子按钮添加到面板
                this.GUIJPanel.add(this.bt[i][j]);
                /*根据array数组中的数据来设置柜子的颜色
                *   绿色：柜子闲置     灰色：柜子占用
                * */
                if (this.GetBoxState(i, j,false)) {                                     //false参数代表只获取柜子当前的状态，不对柜子的状态进行更改
                    this.bt[i][j].BUTTON_COLOR1 = new Color(61, 145, 64);
                    this.bt[i][j].BUTTON_COLOR2 = new Color(0, 201, 87);
                } else {
                    this.bt[i][j].BUTTON_COLOR1 = new Color(0, 0, 0);
                    this.bt[i][j].BUTTON_COLOR2 = new Color(88, 87, 86);
                }
                if (j < 3) {
                    this.bt[i][j].setBounds(x, y, width, height);
                } else this.bt[i][j].setBounds(x + 60, y, width, height);
                //添加每个柜子的监听器，并将柜子的下标传给监听器。目的：为了派件和取消派件时对柜子的状态进行更新。
                this.bt[i][j].addActionListener(new MyAc(i, j));
                x += 150;
            }
            x = 10;
            y += height + 20;
        }
    }

    /*  第三个参数的意义：
    *   true：检查柜子的状态，并更改其状态----用于快递员对已经派件的订单惊进行取消。
    *   false：只检查柜子的状态，不对柜子的状态进行更改。
    *   返回值代表柜子的状态：true：闲置-----false：占用；
     */
    public boolean GetBoxState(int i, int j,Boolean bo) {
        ArrayList array = new ArrayData<>().getArray();
        LinkData li;
        LinkNode temp;
        InforData data;
        li = (LinkData) array.get(i);
        temp = li.head.next;
        for (int k = 0; k < j + 1; k++) {
            data = (InforData) temp.data;
            if (k == j) {
                if(bo==true){
                    System.out.println("取件码："+data.getRandom_num()+"--已失效");
                    temp.data=null;
                    //更新数据存储
                    new ArrayData<>().setArray(array);
                    //返回true的目的是，判断上条语句是否执行成功。
                    return true;
                }else{
                    if (Objects.equals(data, null)) {
                        return true;
                    } else
                        return false;
                }
            }
            temp = temp.next;
        }
        return false;
    }

    private class MyAc implements ActionListener {
        int i, j;

        public MyAc(int i, int j) {
            this.i = i;
            this.j = j;
        }
        public MyAc(){

        }
        @Override
        public void actionPerformed(ActionEvent e) {
            String BuStr=e.getActionCommand();
            if(BuStr.equals("退出")){
                new GUI_Set();
                Admin_Set.this.dispose();
            }else{
                if (Admin_Set.this.GetBoxState(i, j,false)) {                                   //对闲置柜子进行派件
                    //记录点击的柜子下标
                    System.out.println(i+"\t"+j);
                    //将下标传给派件界面，目的：派件时准确的添加快递信息到对应数据存储位置。
                    new Admin_Send(i,j);
                    Admin_Set.this.dispose();
                } else{                                             //对已占用的柜子进行取消派件。
                    //弹窗提醒
                    int n=JOptionPane.showConfirmDialog(null,"是否取出该柜子的快递？","警告",JOptionPane.YES_NO_CANCEL_OPTION);
                    if(n==1){

                    }else if(n==0){
                        if(!Admin_Set.this.GetBoxState(i,j,false)){
                            //取消派件时对快递员的身份进行验证。
                            String password=JOptionPane.showInputDialog(null,"请输入用户名密码：","验证身份",JOptionPane.WARNING_MESSAGE);
                            if(Objects.equals(password,"123321")){
                                ////////*****新更改的
                                //身份验证成功后，对柜子的状态进行更改，更改成功弹窗提醒，刷新界面。
                                if(Admin_Set.this.GetBoxState(i,j,true)){
                                    JOptionPane.showMessageDialog(Admin_Set.this.GUIJPanel, "取消派件成功！");
                                    new Admin_Set<>();
                                    Admin_Set.this.dispose();
                                }else{
                                    JOptionPane.showMessageDialog(Admin_Set.this.GUIJPanel, "操作失败！");
                                }
                            }else{
                                JOptionPane.showMessageDialog(Admin_Set.this.GUIJPanel,"密码错误！\n操作失败！");
                            }
                        }else
                            JOptionPane.showMessageDialog(Admin_Set.this.GUIJPanel, "操作有误！");
                    }else;
                }
            }
        }
    }
}
