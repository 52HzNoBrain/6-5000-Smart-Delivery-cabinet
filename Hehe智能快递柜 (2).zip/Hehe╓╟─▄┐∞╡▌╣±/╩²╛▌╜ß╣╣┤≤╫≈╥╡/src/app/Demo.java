package app;

public class Demo{
    public Demo(){
        new GUI_Set();
    }
    public static void main(String[]  args){
        new Demo();
    }
}

