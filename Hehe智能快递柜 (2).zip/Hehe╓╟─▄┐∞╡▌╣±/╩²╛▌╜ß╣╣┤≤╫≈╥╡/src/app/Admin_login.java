package app;

import AC_FC.TextFc;
import Module_Beautify.MyJButton;
import Module_Beautify.MyJTextFileldlimit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/*
* 登录界面
* */
public class Admin_login extends MyJFrame{
    //目的，身份验证成功，关闭GUI_Set界面
    GUI_Set gui_set;
    JLabel title=new JLabel("快递员登录界面");
    JTextField admin=new JTextField("请输入用户名");
    JTextField password=new JTextField("请输入用户密码");
    JButton login=new MyJButton("登录");
    public Admin_login(GUI_Set gui_set){
        super();
        this.gui_set=gui_set;
        //设置关闭时不关闭整个程序。
        this.setDefaultCloseOperation(2);
        //重新设置界面的属性
        this.setSize(600, 300);
        this.setLocationRelativeTo(null);
        this.AddModule();
        this.SetModule();
    }

    public void AddModule(){
        this.GUIJPanel.add(title);
        this.GUIJPanel.add(admin);
        this.GUIJPanel.add(password);
        this.GUIJPanel.add(login);
    }
    public void SetModule(){
        //标题位置及字体
        this.title.setBounds(200,20,200,30);
        this.title.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //文本框及按钮的位置
        this.admin.setBounds(150,70,300,40);
        this.password.setBounds(150,130,300,40);
        this.login.setBounds(250,190,100,30);
        //文本框及按钮的样式
        this.admin.setDocument(new MyJTextFileldlimit(8,this.admin,"请输入用户名",14));
        this.admin.setDocument(new MyJTextFileldlimit(8,this.password,"请输入用户密码",14));
        this.login.setFont(new Font("TimesRoman",Font.PLAIN,20));
        //文本框中文本的消失与恢复
        this.admin.addFocusListener(new TextFc("请输入用户名",this.admin));
        this.password.addFocusListener(new TextFc("请输入用户密码",this.password));
        //登录按钮监听器
        this.login.addActionListener(new MyAc());
    }

    class MyAc implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(Admin_login.this.admin.getText().equals("admin")&&Admin_login.this.password.getText().equals("123321")){
                new Admin_Set<>();
                //关闭登录界面
                Admin_login.this.dispose();
                //关闭GUi_Set界面
                Admin_login.this.gui_set.dispose();
            }else{
                JOptionPane.showMessageDialog(Admin_login.this.GUIJPanel, "用户名或密码错误！\n请重新输入");
            }
        }
    }
}

