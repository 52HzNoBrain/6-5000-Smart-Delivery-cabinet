package app;

import AC_FC.TextFc;
import Module_Beautify.MyJButton;
import Module_Beautify.MyJTextFileldlimit;
import data.SearchInfor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
* 开始界面，采用精准布局。
* */
public class GUI_Set extends MyJFrame{
    JLabel logo_icon=new JLabel(new ImageIcon("src/icon/logo.png"));                //图标
    JLabel title=new JLabel("Hehe智能快递柜");                                           //标题
    JTextField pick_text =new JTextField("请输入取件码",50);                     //输入取件码文本框
    JButton express_Button =new MyJButton("寄快递");                                     //寄快递按钮
    JButton admin_Button =new MyJButton("快递员登录");                                    //快递员登录按钮
    JButton pick_Button =new MyJButton("取件");                                         //取件按钮
    JButton Empty_text=new MyJButton("清空");                                           //清空按钮
    JButton [] num;                                                                         //数字键盘数组
    public GUI_Set(){
        //添加组件按钮
        this.AddModule();
        //添加数字键盘组件
        this.SetAddNum();
        //设置组件的大小及其位置
        this.SetModuleSL();
        //给按钮添加监听器
        this.addAC();
    }
    //此构造方法是为了让Admin_Send类可以获取到此类的数字键盘，参数没有任何意义所在。
    public GUI_Set(String str){
        this.setVisible(false);
    }
    /*添加组件方法
     * */
    private void AddModule(){
        this.GUIJPanel.add(title);
        this.GUIJPanel.add(pick_text);
        this.GUIJPanel.add(express_Button);
        this.GUIJPanel.add(admin_Button);
        this.GUIJPanel.add(pick_Button);
        this.GUIJPanel.add(Empty_text);
        this.GUIJPanel.add(logo_icon);
    }


    /*键盘数字，设值每个数字键盘的文本；
     * */
    public  MyJButton[] getNumButton(){
        String numkey="1234567890";
        String num_str;
        MyJButton[] num =new MyJButton[numkey.length()];
        for(int i=0;i<numkey.length();i++){
            num_str=numkey.substring(i,i+1);
            num[i]=new MyJButton(num_str);
        }
        //设置此类的全局变量num，位SetAddnum()创造前提条件。
        this.num=num;
        //设置返回值，为了被Admin_Send类调用。
        return num;
    }

    /*将添加数字按钮、设置布局、添加监听器封装成一个方法，减少程序时间复杂度
     * */
    void SetAddNum(){
        //获取数字的JButton数组（全局变量）
        this.getNumButton();
        int i=0;                        //记录已操作数字按钮的个数。
        int num=25;                     //
        for (JButton jButton : this.num) {
            this.GUIJPanel.add(jButton);
            if(i<3){
                jButton.setBounds(num,235,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                //设置三个后实现按钮再面板上的换行
                if(i==2)
                    num=25;
                i++;
            }
            else if(i<6)
            {
                jButton.setBounds(num,360,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                if(i==5)
                    num=25;
                i++;

            }
            else if(i<9)
            {
                jButton.setBounds(num,485,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
                num+=240;
                if(i==8)
                    num=25;
                i++;
            }
            else{
                jButton.setBounds(num,610,160,90);
                jButton.setFont(new Font("TimesRoman",Font.PLAIN,25));
            }
            //添加每个数字按钮监听器
            jButton.addActionListener(new GUI_Set.MyAc());
        }
    }

    private void SetModuleSL(){
        //设置标题位置及字体样式
        this.title.setFont(new Font("TimesRoman",Font.PLAIN,40));
        this.title.setBounds(250,0,500,100);
        //设置取件码文本框位置，限制文本框输入长度，以及设置字体大小
        this.pick_text.setBounds(20,100,650,100);
        this.pick_text.setDocument(new MyJTextFileldlimit(8,this.pick_text,"请输入取件码",25));
        //设置寄快递和快递员登录按钮位置大小。
        this.express_Button.setBounds(720,235,220,200);
        this.express_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
        this.admin_Button.setBounds(720,500,220,200);
        this.admin_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //清空按钮
        this.Empty_text.setBounds(265,610,160,90);
        this.Empty_text.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //设置取件按钮
        this.pick_Button.setBounds(505,610,160,90);
        this.pick_Button.setFont(new Font("TimesRoman",Font.PLAIN,25));
        //设置logo图标的位置。
        this.logo_icon.setBounds(670,25,320,200);

    }

    /*给按钮添加监听器
     * */
    private void addAC(){
        //按钮监听器
        this.express_Button.addActionListener(new GUI_Set.MyAc());
        this.admin_Button.addActionListener(new GUI_Set.MyAc());
        this.Empty_text.addActionListener(new GUI_Set.MyAc());
        this.pick_Button.addActionListener(new GUI_Set.MyAc());
        //实现提示文字提示的消失与恢复
        this.pick_text.addFocusListener(new TextFc("请输入取件码",this.pick_text));
    }

    //所有按钮监听器
    class MyAc implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //获取点击按钮的文本，区别响应
            String BuStr=e.getActionCommand();
            if(BuStr.equals("寄快递")){
                JOptionPane.showMessageDialog(GUI_Set.this.GUIJPanel, "对不起！\n该功能未开放！");
            }
            else if(BuStr.equals("快递员登录")){
                //快递员登录界面
                new Admin_login(GUI_Set.this);                                      //参数的目的是当快递员身份成功后，关闭GUI_Set界面
            }else if(BuStr.equals("清空")){
                //重置文本框的文本
                GUI_Set.this.pick_text.setText("请输入取件码");
                GUI_Set.this.pick_text.setForeground(Color.LIGHT_GRAY);
            }else if(BuStr.equals("取件")){
                //调用SearchInfor的构造函数，返回取件码是否存在。
                Boolean bo=new SearchInfor(GUI_Set.this.pick_text.getText()).isBo();
                if(bo){
                    JOptionPane.showMessageDialog(GUI_Set.this.GUIJPanel, "取件成功！");
                }else
                    JOptionPane.showMessageDialog(GUI_Set.this.GUIJPanel, "取件失败！\n请输入正确的取件码");
            }else{
                /*数字键盘按钮点击事件处理。
                * */
                //直接点击数字按钮时，清空文本框。
                if(GUI_Set.this.pick_text.getText().equals("请输入取件码"))
                    GUI_Set.this.pick_text.setText("");
                GUI_Set.this.pick_text.setForeground(Color.BLACK);
                //设置当按钮输入为8位时，不再响应其按钮点击事件（限制取件码的输入）
                if(GUI_Set.this.pick_text.getText().length()<8){
                    GUI_Set.this.pick_text.setText(GUI_Set.this.pick_text.getText()+BuStr);
                }
                else return;
            }
        }
    }
}
