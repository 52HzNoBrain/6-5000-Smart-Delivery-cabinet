package Module_Beautify;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import java.awt.*;

/*
*原文链接：https://blog.csdn.net/k_young1997/article/details/84573872
* 此类的代码取于上述网站
* 此类用于限制文本框长度和设置文本框样式
**/
public class MyJTextFileldlimit extends PlainDocument {
    private int limit;
    JTextField text;
    String str;
    int fontsize;
    public MyJTextFileldlimit(int limit, JTextField text,String str,int fontsize) {
        super(); //调用父类构造
        this.text=text;
        this.str=str;
        this.fontsize=fontsize;
        this.limit = limit;
        this.MysetFont();
    }
    public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
        if(str == null) return;

        //下面的判断条件改为自己想要限制的条件即可，这里为限制输入的长度
        if((getLength() + str.length()) <= limit) {
            super.insertString(offset, str, attr);//调用父类方法
        }
    }
    public void MysetFont(){
        //设置文本框的初始文本。
        this.text.setText(this.str);
        //设置文本框的字体样式
        this.text.setFont(new Font("TimesRoman",Font.PLAIN,this.fontsize));
        //设置初始文本框的初始颜色(白灰色)
        this.text.setForeground(Color.lightGray);
        //设置文本框透明，美化窗口
        this.text.setOpaque(false);
        //设置文本框颜色和边框圆角、
        this.text.setBorder(new MyTextBorder(new Color(169, 174, 255),1,true));
    }
}
